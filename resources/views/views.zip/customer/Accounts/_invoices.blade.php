<div class="row">
    <div class="col-12">
        <div class="card">
            <table class="table datatables-basic">
                <thead>
                <tr>
                    <th></th>
                    <th></th>
                    <th>{{ __('locale.labels.id') }}</th>
                    <th>#</th>
                    <th>{{__('locale.labels.date')}}</th>
                    <th>{{__('locale.labels.type')}}</th>
                    <th>{{__('locale.labels.details')}}</th>
                    <th>{{__('locale.labels.amount')}}</th>
                    <th>{{__('locale.labels.status')}}</th>
                    <th></th>
                </tr>
                </thead>
            </table>
        </div>
    </div>
</div>
